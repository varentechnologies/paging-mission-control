/*
analyzeData.cpp
Author: Joel Norris
Date: 3/24/19
*/

#include "analyzeData.h"

/*
Name: readFile
Description: This function opens up the file record of choice and parses the data, line by line, into a vector.

input file format: <timestamp>|<satellite-id>|<red-high-limit>|<yellow-high-limit>|<yellow-low-limit>|<red-low-limit>|<raw-value>|<component>
exmaple input:		20180101 23:01:05.001|1001|101|98|25|20|99.9|TSTAT

Ingest status telemetry data and create alert messages for the following violation conditions:
	- If for the same satellite there are three battery voltage readings that are under the red low limit within a five minute interval.
	- If for the same satellite there are three thermostat readings that exceed the red high limit within a five minute interval.
*/
void readFile()
{
	string fileName;
	string line;
	string data;
	vector<string> dataVector;

	map<string, int> TSTATLimitCount;   // Map to check how many times each satellite thermostat reading exceeds the red high limit
	map<string, int> BATTLimitCount;	// Map to check how many times each satellite voltage reading is below the red low limit
	map<string, string> timestampMap;	/* Holds 1st violation timestamp value for each satellite. Holds separate values for TSTAT & BATT
										ie. timestampMap: (1st time violations for both TSTAT & BATT for two different satellites)
										[1000TSTAT][value]
										[1001TSTAT][value]
										[1000BATT][value]
										[1001BATT][value]
										*/
	
	//ifstream statusRecords("test.txt");
	ifstream statusRecords("Telemetry_Status_Records.txt");
	if (statusRecords.is_open())
	{
		//getline(statusRecords, line);
		while (getline(statusRecords, line))
		{
			dataVector.clear();
			istringstream ss(line);
			while (getline(ss, data, '|'))		// Parses line based on "|" and pushes data values into a vector
				dataVector.push_back(data);

			checkData(dataVector, TSTATLimitCount, BATTLimitCount, timestampMap);

		}

		printAlert(TSTATLimitCount, BATTLimitCount, timestampMap);
	}
}


/*
Name: checkData
Description: This function stores needed vector values into string variables and checks to see if either:
			 1) A battery voltage reading is under the red low limit
									OR
			 2) A thermostat reading exceeds the red high limit

			 A boolean type is returned based upon the variable check outcome.
			 input file format: <timestamp>|<satellite-id>|<red-high-limit>|<yellow-high-limit>|<yellow-low-limit>|<red-low-limit>|<raw-value>|<component>
			 exmaple input:		20180101 23:01:05.001|1001|101|98|25|20|99.9|TSTAT
*/
void checkData(vector<string> dataVector, map<string, int> &TSTATLimitCount, map<string, int> &BATTLimitCount, map<string, string> &timestampMap)
{
	string timestamp, satelliteId, redHighLimit, redLowLimit, rawValue, component;
	int value = 0;

	// Store needed vector values into string variables
	timestamp = dataVector[0], satelliteId = dataVector[1];
	redHighLimit = dataVector[2], redLowLimit = dataVector[5], rawValue = dataVector[6];
	component = dataVector[7];


	if (component == "TSTAT" && stod(rawValue) > stod(redHighLimit))	// Satellite thermostat check
	{		
		if (TSTATLimitCount.count(satelliteId) == 1)		// If Satellite Id exists within the map, add 1 to the violation value total
		{
			value = TSTATLimitCount.at(satelliteId);
			value++;
			TSTATLimitCount[satelliteId] = value;

		}
		else												 // Else, add Id to the map, initialize violation value to 1, & record timestamp value
		{
			TSTATLimitCount.insert(pair<string, int>(satelliteId, 1));
			timestampMap.insert(pair<string, string>(satelliteId + "TSTAT", timestamp));	// Record timestamp of violation
		}
	}
	else if (component == "BATT" && stod(rawValue) < stod(redLowLimit))	// Satelite battery voltage check
	{
		if (BATTLimitCount.count(satelliteId) == 1)			// If Satellite Id exists within the map, add 1 to the violation value total
		{
			value = BATTLimitCount.at(satelliteId);
			value++;
			BATTLimitCount[satelliteId] = value;
		}
		else                                               // Else, add Id to the map, initialize violation value to 1, & record timestamp value             
		{
			BATTLimitCount.insert(pair<string, int>(satelliteId, 1));
			timestampMap.insert(pair<string, string>(satelliteId + "BATT", timestamp));	// Record timestamp of violation
		}
	}
}


/*
Name: printAlert
Description: This function loops through the TSTAT and BATT maps to check for any violation totals greater than 2.
			If a violation alert needs to be printed, the timestamp is taken from the timestamp map and applied to the alert.
			Output format:

			satelliteId: 1000,
			severity: "RED HIGH",
			component: "TSTAT",
			timestamp: "2018-01-01T23:01:38.001Z"

			satelliteId: 1000,
			severity: "RED LOW",
			component: "BATT",
			timestamp: "2018-01-01T23:01:09.521Z"

*/
void printAlert(map<string, int> TSTATLimitCount, map<string, int> BATTLimitCount, map<string, string> timestampMap)
{
	string timestamp, formattedTimestamp;
	for (auto it = TSTATLimitCount.begin(); it != TSTATLimitCount.end(); ++it)
	{
		if (it->second > 2)
		{
			// obtain proper timestamp notation and print alert
			timestamp = timestampMap.at(it->first + "TSTAT");
			formattedTimestamp = formatTimestamp(timestamp);
			cout << "satelliteId: " << it->first << "," << endl;
			cout << "severity: RED HIGH" << "," << endl;
			cout << "component: TSTAT" << "," << endl;
			cout << "timestamp: " << formattedTimestamp << endl << endl;
		}
	}
	for (auto it = BATTLimitCount.begin(); it != BATTLimitCount.end(); ++it)
	{
		if (it->second > 2)
		{
			// obtain proper timestamp notation and print alert
			timestamp = timestampMap.at(it->first + "BATT");
			formattedTimestamp = formatTimestamp(timestamp);
			cout << "satelliteId: " << it->first << "," << endl;
			cout << "severity: RED LOW" << "," << endl;
			cout << "component: BATT" << "," << endl;
			cout << "timestamp: " << formattedTimestamp << endl << endl;
		}
	}
}

/*
Name: formatTimestamp
Description: This function takes the timestamp format from the input file and converts it from
			20180101 23:01:05.001 to 2018-01-01 23:01:05.001

*/
string formatTimestamp(string timestamp)
{
	string year, month, day, time;

	year = timestamp.substr(0, 4);
	month = timestamp.substr(4, 2);
	day = timestamp.substr(6, 2);
	time = timestamp.substr(9);

	timestamp = year + "-" + month + "-" + day + " " + time;
	return timestamp;
}

