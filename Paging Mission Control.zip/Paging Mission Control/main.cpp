/*
main.cpp
Author: Joel Norris
Date: 3/24/19

Project Objective:
The objective of the project is to develop a monitoring and alert application to recieve an ascii text file
holding status telemetry data in order to create alert messages in the case of certain violation scenarios.

Requirements: Ingest status telemetry data and create alert messages for the following violation conditions:
	- If for the same satellite there are three battery voltage readings that are under the red low limit within a five minute interval.
	- If for the same satellite there are three thermostat readings that exceed the red high limit within a five minute interval.

Description: This is the main cpp file for the paging mission control project.
*/

#include "analyzeData.h"


void main()
{
	cout << "Welcome to the monitoring and alert system for satellite ground operations." << endl << endl;
	
	readFile();
}

