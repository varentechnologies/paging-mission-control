#pragma once
/*
analyzeData.h
Author: Joel Norris
Date: 3/24/19
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
using std::string;
using std::ifstream;
using std::istringstream;
using std::vector;
using std::map;
using std::pair;
using std::cout;
using std::cin;
using std::endl;


void readFile();
void checkData(vector<string> dataVector, map<string, int> &TSTATLimitCount, map<string, int> &BATTLimitCount, map<string, string> &timestampMap);
void printAlert(map<string, int> TSTATLimitCount, map<string, int> BATTLimitCount, map<string, string> timestampMap);
string formatTimestamp(string timestamp);
